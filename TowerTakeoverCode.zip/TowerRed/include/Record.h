#pragma once
void Record();