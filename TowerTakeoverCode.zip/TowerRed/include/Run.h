#pragma once

#include "Vex.h"

using namespace vex; 

void Break(const char str[]);

void spin(float a, motor * m);

void Run();