#include "vex.h"
using namespace vex;
using namespace std;
//Immediatly stops the program and prints a given error message
void Break(const char str[]){
  while(1){
  Brain.Screen.clearScreen(blue);
  Brain.Screen.printAt(100, 100, str);
      vex::task::sleep(100);
  }
}

void spin(float a, motor * m){
  if(a<=0){
  m->spin(directionType::rev, fabs(a), voltageUnits::mV);
  }
  else{
  m->spin(directionType::fwd, fabs(a), voltageUnits::mV);
  }
}

void Run(){

    FILE *fp;
    if(fopen(FILENAME, "r")==nullptr){
      Break("file not found");
    }
    fp=fopen(FILENAME, "r");

    float lastTime=0;  //stores the last time the program was executed
    static float m1, m2, m3, m4, m5, m6, m7, m8;         
    //Excutes every 28 miliseconds
    while(Brain.timer(timeUnits::sec)<=AUTOLENGTH){
        if(lastTime<Brain.timer(timeUnits::msec)-28){
       
            //Stops the auto if the end of file is reached
            if(feof(fp)){ 
                Brain.Screen.printAt(200, 200, "Playback complete, %f",Brain.timer(timeUnits::msec));
                RightMotorF.spin(directionType::rev, 0, voltageUnits::mV);
                RightMotorB.spin(directionType::rev, 0, voltageUnits::mV);
                LeftMotorB.spin(directionType::rev, 0, voltageUnits::mV);
                LeftMotorF.spin(directionType::rev, 0, voltageUnits::mV);
                fclose(fp);

                while(1){
                     vex::task::sleep(100);
                }       
            }

            fscanf(fp, "%f %f %f %f %f %f %f %f",  &m1, &m2, &m3, &m4, &m5, &m6, &m7, &m8);
            spin(m1, &RightMotorF);
            spin(m2, &RightMotorB);
            spin(m3, &LeftMotorF);
            spin(m4, &LeftMotorB);
            spin(m5, &IntakeR);
            spin(m6, &IntakeL);
            spin(m7, &Lift);
            spin(m8, &Pusher);
          
            lastTime=Brain.timer(timeUnits::msec);//updates the lastTime is program was run
          }
    }
  

}
