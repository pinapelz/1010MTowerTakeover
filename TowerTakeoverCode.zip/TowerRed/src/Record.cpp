#include "vex.h"
void Record(){
    static bool declared=false;
    static int lastTime;
    static FILE *fp;
    static FILE *fpTime;
    if(declared==false){
        lastTime=0;
        if(fopen(FILENAME, "w")==nullptr){
            Break("file could not be written");
        }
        fp = fopen(FILENAME, "w");
      
        fpTime = fopen("TIMERECORDRED.txt", "w");
        /*/
        Opens all the file, as in auto, but in write mode.
        Write mode creates a new file if no file is present. 
        If file is present, it clears and overwrites it. 
        FILE variables are local to the usercontrol or auto function, not static.
        /*/
        declared=true;
    }
    if(Brain.timer(timeUnits::sec)<=AUTOLENGTH) {
        
        if(lastTime<Brain.timer(timeUnits::msec)-29){
            lastTime=Brain.timer(timeUnits::msec);
            fprintf(fpTime, " %f\n", Brain.timer(timeUnits::msec));
            fprintf(fp, " %f",  (double)vexMotorVoltageGet(RightMotorF.index()));
            fprintf(fp, " %f",  (double)vexMotorVoltageGet(RightMotorB.index()));
            fprintf(fp, " %f",  (double)vexMotorVoltageGet(LeftMotorF.index()));
            fprintf(fp, " %f",  (double)vexMotorVoltageGet(LeftMotorB.index()));
            fprintf(fp, " %f",  (double)vexMotorVoltageGet(IntakeR.index()));
            fprintf(fp, " %f",  (double)vexMotorVoltageGet(IntakeL.index()));
            fprintf(fp, " %f",  (double)vexMotorVoltageGet(Lift.index()));
            fprintf(fp, " %f\n",  (double)vexMotorVoltageGet(Pusher.index()));            
        }
        /*/
        This if statement ensures the motor voltage is written every 29 ms.
        The shorter the cycle speed, the more accurate the playback.
        However, sampling speed was sacrificed to better sync motion and replication.
        Cycle may vary based on brain, test and check. 
        /*/
    }
    else{
        fclose(fpTime);
        fclose(fp);
        Brain.Screen.clearScreen();
        Brain.Screen.print("write complete");
    }
    /*/
    Stops all motors, closes file streams, sleeps indefinitly, and informs the user.
    /*/
}